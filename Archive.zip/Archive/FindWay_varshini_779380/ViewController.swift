//
//  ViewController.swift
//  FindWay_varshini_779380
//
//  Created by Valliveti Vidya Jayakumar on 2020-06-13.
//  Copyright © 2020 Valliveti Vidya Jayakumar. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    
    private let locationManager = CLLocationManager()
    private var currentCoordinate: CLLocationCoordinate2D?
    
    var currentLoc: CLLocationCoordinate2D!
    
    var destinationLoc: CLLocationCoordinate2D!
    let  centerMapButton: UIButton = {
        
    let button = UIButton(type: .system)
        button.setImage(UIImage(named: "Image")?.withRenderingMode(.alwaysOriginal), for: .normal)
        button.addTarget(self, action: #selector(handleCenterOnUserLocation), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
        
    }()
    
    @IBAction func ZoomInButton(_ sender: Any) {
        let span = MKCoordinateSpan(latitudeDelta: mapView.region.span.latitudeDelta/2, longitudeDelta: mapView.region.span.longitudeDelta/2)
        let region = MKCoordinateRegion(center: mapView.region.center, span: span)
        mapView.setRegion(region, animated: true)
    }
    @IBAction func ZoomOutButton(_ sender: Any) {
        
        let span = MKCoordinateSpan(latitudeDelta: mapView.region.span.latitudeDelta*2, longitudeDelta: mapView.region.span.longitudeDelta*2)
        let region = MKCoordinateRegion(center: mapView.region.center, span: span)
        mapView.setRegion(region, animated: true)
    }
    @IBAction func GetRouteButton(_ sender: Any) {
        constructRoute(type: .automobile)
    }
    @IBAction func WalkRouteButton(_ sender: Any) {
        constructRoute(type: .walking)
    }
    //    let ZoomInMapButton: UIButton = {
//
//    let button = UIButton(type: .system)
//        button.setImage(UIImage(named:"Zoom-In")?.withRenderingMode(.alwaysOriginal), for: .normal)
//        button.addTarget(self, action: #selector(zoomToLatestLocation(with:)), for: .touchUpInside)
//        button.translatesAutoresizingMaskIntoConstraints = false
//        return button
//
//    }()
//
//    let ZoomOutMapButton: UIButton = {
//
//        let button = UIButton(type: .system)
//        button.setImage(UIImage(named: "Zoom-Out")?.withRenderingMode(.alwaysOriginal), for: .normal)
//        button.addTarget(self, action: #selector(zoomToLatestLocation(with:)), for: .touchUpInside)
//        button.translatesAutoresizingMaskIntoConstraints = false
//        return button
//
//    }()
    
    
    
    private var destinations: [MKPointAnnotation]
        = []
    private var currentRoute: MKRoute?
    

    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        configureLocationServices()
        gesture()
        
//        view.addSubview(centerMapButton)
//        centerMapButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -44).isActive = true
//        centerMapButton.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -12).isActive = true
//        centerMapButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
//        centerMapButton.widthAnchor.constraint(equalToConstant: 50).isActive = true
//        centerMapButton.layer.cornerRadius = 50 / 2
//        centerMapButton.alpha = 1
        
//        view.addSubview(ZoomInMapButton)
//        ZoomInMapButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -44).isActive = true
//        ZoomInMapButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: -12).isActive = true
//        ZoomInMapButton.heightAnchor.constraint(equalToConstant: 60).isActive = true
//        ZoomInMapButton.widthAnchor.constraint(equalToConstant: 75).isActive = true
//        ZoomInMapButton.layer.cornerRadius = 50 / 2
//        ZoomInMapButton.alpha = 1
//
//        view.addSubview(ZoomOutMapButton)
//        ZoomOutMapButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -120).isActive = true
//        ZoomOutMapButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: -12).isActive = true
//        ZoomOutMapButton.heightAnchor.constraint(equalToConstant: 60).isActive = true
//        ZoomOutMapButton.widthAnchor.constraint(equalToConstant: 70).isActive = true
//        ZoomOutMapButton.layer.cornerRadius = 50 / 2
//        ZoomOutMapButton.alpha = 1
        
    }
    
    @objc func handleCenterOnUserLocation() {
//       configureLocationServices()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
//    --------------------------------------
    private func gesture(){
        mapView.delegate = self
        let longTapGesture = UILongPressGestureRecognizer(target: self, action: #selector(longTap))
        mapView.addGestureRecognizer(longTapGesture)
    }
    
    
    @objc func longTap(sender: UIGestureRecognizer){
        print("long tap")
        if sender.state == .began {
            let locationInView = sender.location(in: mapView)
            let locationOnMap = mapView.convert(locationInView, toCoordinateFrom: mapView)
            addAnnotation(location: locationOnMap)
        }
    }
    
    func addAnnotation(location: CLLocationCoordinate2D){
        removeAnnotation()
        removeOverlay()
        destinationLoc = location
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = "Find Route"
        annotation.subtitle = ""
        self.mapView.addAnnotation(annotation)
        
    }
    func removeAnnotation(){
        let annotationsToRemove = mapView.annotations.filter { $0 !== mapView.userLocation }
        mapView.removeAnnotations( annotationsToRemove )
    }
      
    
    func getCurrentLocation(){
        if(CLLocationManager.authorizationStatus() == .authorizedWhenInUse ||
            CLLocationManager.authorizationStatus() == .authorizedAlways) {
            currentLoc = locationManager.location?.coordinate
                    }
    }
    func removeOverlay(){
        for poll in mapView.overlays {
            mapView.remove(poll)
        }
    }
//    -----------------------------------------
    

    
private func configureLocationServices(){
      locationManager.delegate = self
      
      let status = CLLocationManager.authorizationStatus()
      
      if CLLocationManager.authorizationStatus() == .notDetermined {
          locationManager.requestAlwaysAuthorization()
      }else if status == .authorizedAlways || status == .authorizedWhenInUse {
          beginLocationUpdates(locationManager: locationManager)
      }
  }
  
  private func beginLocationUpdates(locationManager: CLLocationManager){
      mapView.showsUserLocation = true
      locationManager.desiredAccuracy = kCLLocationAccuracyBest
      locationManager.startUpdatingLocation()
      
  }
  
  private func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D){
      let zoomRegion = MKCoordinateRegionMakeWithDistance(coordinate, 2000, 2000)
      mapView.setRegion(zoomRegion, animated: true)
      currentLoc = coordinate
      
  }

//
//    @objc private func beginLocationUpdates(locationManager: CLLocationManager) {
//
//        mapView.showsUserLocation = true
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.startUpdatingLocation()
//
//
//    }
//
//    @objc private func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D) {
//
//        let zoomRegion = MKCoordinateRegion(center: coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
//        mapView.setRegion(zoomRegion, animated: true)
//    }

//    private func addAnnotations() {
        
//        let universityOfTorontoAnnotation = MKPointAnnotation()
//        universityOfTorontoAnnotation.title = "University Of Toronto"
//        universityOfTorontoAnnotation.coordinate = CLLocationCoordinate2D(latitude: 43.656997372, longitude: -79.390331772)
//
//        let sunnybrookParkAnnotation = MKPointAnnotation()
//        sunnybrookParkAnnotation.title = "Sunnybrook Park"
//        sunnybrookParkAnnotation.coordinate = CLLocationCoordinate2D(latitude: 43.71863, longitude: -79.350388)
//
//        destinations.append(universityOfTorontoAnnotation)
//        destinations.append(sunnybrookParkAnnotation)
//
//        mapView.addAnnotation(universityOfTorontoAnnotation)
//        mapView.addAnnotation(sunnybrookParkAnnotation)
//    }
    
    func checkForLocation() {
                    getCurrentLocation()
                    let alert = UIAlertController(title: "Please Select a destination!", message: "", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: { action in
                      switch action.style {
                      case .default:
                        print("default")
                      case .cancel:
                        print("cancel")
                      case .destructive:
                        print("des")
                        }
                    }))
                    self.present(alert, animated: true, completion: nil)
                    
                    print("no destination")
                
    }
    
    private func constructRoute(type: MKDirectionsTransportType) {
        if currentLoc == nil || destinationLoc == nil {
        checkForLocation()
        }
        else {
            removeOverlay()
        let directionsRequest = MKDirections.Request()
        directionsRequest.source = MKMapItem(placemark: MKPlacemark(coordinate: currentLoc))
        directionsRequest.destination = MKMapItem(placemark: MKPlacemark(coordinate: destinationLoc))
        directionsRequest.requestsAlternateRoutes = true
        directionsRequest.transportType = type
        
        let directions = MKDirections(request: directionsRequest)
        
        directions.calculate { [weak self] (directionsResponse, error) in
            guard let strongSelf = self else { return }
            
            
            if let error = error {
                print(error.localizedDescription)
            } else if let response = directionsResponse, response.routes.count > 0 {
                
                strongSelf.currentRoute = response.routes[0]
                
                strongSelf.mapView.add(response.routes[0].polyline)
                strongSelf.mapView.setVisibleMapRect(response.routes[0].polyline.boundingMapRect, animated: true)
                
            }
            
        }
        }
        
        
    }
    
}

extension ViewController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        print("Did get latest location")
        
        guard let latestLocation = locations.first else { return }
        
        if currentCoordinate == nil {
            zoomToLatestLocation(with: latestLocation.coordinate)
//        addAnnotations()
//            constructRoute(userLocation: latestLocation.coordinate)
        }

        currentCoordinate = latestLocation.coordinate
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        print("The status changed")
        
        if status == .authorizedAlways || status == .authorizedWhenInUse {
            
            beginLocationUpdates(locationManager: manager)
        }
       
    }
    
}

extension ViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        guard let currentRoute = currentRoute else {
            return MKOverlayRenderer()
        }
        
        let polyLineRenderer = MKPolylineRenderer(polyline: currentRoute.polyline)
        polyLineRenderer.strokeColor = UIColor.blue
        polyLineRenderer.lineWidth = 4
        return polyLineRenderer
        
    }
    
//    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
//
//        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "AnnotationView")
//
//        if annotationView == nil {
//            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "AnnotationView")
//        }
//
//        if let title = annotation.title, title == "University Of Toronto" {
//            annotationView?.image = UIImage(named: "tree.png")
//        } else if let title = annotation.title, title == "Sunnybrook Park" {
//            annotationView?.image = UIImage(named: "tree.jpg")
//        } else if annotation === mapView.userLocation {
//            annotationView?.image = UIImage(named: "car")
//        }
//
//        annotationView?.canShowCallout = true
//
//        return annotationView
//    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        print("The annotation was selected: \(String(describing: view.annotation?.title))")
    }
}

